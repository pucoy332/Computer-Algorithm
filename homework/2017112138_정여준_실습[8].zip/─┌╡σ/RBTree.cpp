﻿/*2017112138 정여준*/
#include"RBTree.h"

void RBtree::insert(int z)
{
	int  i = 0;
	node *p, *q;
	node *t = new node; //새로운 노드 생성
	t->key = z; 
	t->left = NULL; 
	t->right = NULL;
	t->color = 'r'; //새로운 노드를 삽입하면 기본적으로 빨간색
	p = root;
	q = NULL;
	if (root == NULL) //빈 트리일 경우
	{
		root = t;
		t->parent = NULL;
	}
	else
	{
		while (p != NULL) 
		{
			q = p;
			if (p->key < t->key)
				p = p->right;
			else
				p = p->left;
		}
		t->parent = q;
		if (q->key < t->key)
			q->right = t;
		else
			q->left = t;
	}
	insertfix(t);
}
void RBtree::insertfix(node *t)
{
	node *u;
	if (root == t) //루트노드는 항상 검정색
	{
		t->color = 'b';
		return;
	}
	while ( t->parent != NULL && t->parent->color == 'r') //연속해서 빨간색이 나오는 경우
	{
		node *g = t->parent->parent; //조부모 노드 g 생성
		if (g->left == t->parent) 
		{
			if (g->right != NULL) //부모의 형제 노드가 있을 때
			{
				u = g->right;
				if (u->color == 'r') //부모의 형제 노드가 적색일 경우 색상 변환
				{
					t->parent->color = 'b';
					u->color = 'b';
					g->color = 'r';
					t = g;
				}
				else if (u->color == 'b') //부모의 형제 노드가 흑색일 경우 
				{
					if (t->parent->right == t) //t가 오른쪽 자식일 때
					{
						t = t->parent;
						leftrotate(t); //좌회전
					}
					t->parent->color = 'b';
					g->color = 'r';
					rightrotate(g); //우회전
				}
			}
			else //부모의 형제노드가 없을 때
			{
				if (t->parent->right == t) //t가 오른쪽 자식일 때
				{
					t = t->parent;
					leftrotate(t); //좌회전
				}
				t->parent->color = 'b';
				g->color = 'r';
				rightrotate(g); //우회전
			}
		}
		else //부모가 조부모의 오른쪽 자식일 때
		{
			if (g->left != NULL) //부모의 형제노드가 있을 때
			{
				u = g->left;
				if (u->color == 'r') //부모의 형제노드가 적색일 때 색상 변환
				{
					t->parent->color = 'b';
					u->color = 'b';
					g->color = 'r';
					t = g;
				}
				else if (u->color == 'b') //부모의 형제노드가 흑색일 때
				{
					if (t->parent->left == t) //t가 왼쪽 자식일 때
					{
						t = t->parent;
						rightrotate(t); //우회전
					}
					t->parent->color = 'b';
					g->color = 'r';
					leftrotate(g); //좌회전
				}
			}
			else //부모의 형제노드가 없을 때
			{
				if (t->parent->left == t) //t가 왼쪽 노드일 떄
				{
					t = t->parent;
					rightrotate(t); //우회전
				}
				t->parent->color = 'b';
				g->color = 'r';
				leftrotate(g); //좌회전
			}
		}
		root->color = 'b'; 
	}
}

void RBtree::leftrotate(node *p) //좌회전
{
	if (p->right == NULL)
		return;
	else
	{
		node *y = p->right; //y를 오른쪽 자식노드로 설정
		if (y->left != NULL) //y의 왼쪽 자식 노드가 있을 때
		{
			p->right = y->left; //y의 왼쪽 자식노드가 p의 오른쪽 자식노드가 된다.
			y->left->parent = p; 
		}
		else
			p->right = NULL;
		if (p->parent != NULL)
			y->parent = p->parent;
		if (p->parent == NULL)
			root = y;
		else
		{
			if (p == p->parent->left) //p가 왼쪽 자식일 떄
				p->parent->left = y;
			else  //p가 오른쪽 자식일 때
				p->parent->right = y;
		}
		y->left = p;
		p->parent = y;
	}
}

void RBtree::rightrotate(node *p) //우회전
{
	if (p->left == NULL) 
		return;
	else
	{
		node *y = p->left; //y를 p의 왼쪽 자식노드로 설정
		if (y->right != NULL) //y의 오른쪽 자식노드가 있을 때
		{
			p->left = y->right; //y의 오른쪽 자식노드가 p의 왼쪽 자식노드가 된다.
			y->right->parent = p;
		}
		else
			p->left = NULL;
		if (p->parent != NULL)
			y->parent = p->parent;
		if (p->parent == NULL)
			root = y;
		else
		{
			if (p == p->parent->left) //p가 왼쪽 자식일 때
				p->parent->left = y;
			else                     //p가 오른쪽 자식일 때
				p->parent->right = y;
		}
		y->right = p;
		p->parent = y;
	}
}

void RBtree::disp()
{
	display(root, 0);
}

void RBtree::display(node *p, int space)
{
	if (root == NULL)
	{
		cout << "\nEmpty Tree.";
		return;
	}
	if (p != NULL)
	{
		int count = 1;
		space += count;
		display(p->right, space);
		cout << endl;

		for (int i = count; i < space; i++)
		{
			cout << "	";
		}
	
		cout << p->key << "(" << p->color << ")" << endl;
		display(p->left, space);
	}
}
