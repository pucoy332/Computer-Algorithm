/*2017112138 ������*/
#include"RBTree.h"

void print_help()
{
	cout << endl << "Commands:" << endl;
	cout << "  +key : Insert (or update) data item" << endl;
	cout << "  Q    : Quit the test program" << endl;
	cout << endl;
}

int main()
{
	int inputKey;                    // ����� �Է� Ű
	char cmd;
	RBtree rb;

	print_help();
	do
	{
		cout << endl << "Command: ";
		cin >> cmd;
		if (cmd == '+')
			cin >> inputKey;

		switch (cmd)
		{
		case '+':                       // ������ ������ ����
			rb.insert(inputKey);
			cout << "Insert : key = " << inputKey
				<< endl;
			rb.disp();
			break;
		case 'Q': case 'q':              // ����
			break;

		default:
			cout << "Inactive or invalid command" << endl;
		}
	} while ((cmd != 'Q') && (cmd != 'q'));
	return 0;
}