﻿/*2017112138 정여준*/
#include<iostream>
using namespace std;

struct node
{
	int key; //값
	node *parent; //부모
	char color; //색
	node *left; //왼쪽 자식
	node *right; //오른쪽 자식
};
class RBtree
{
	node *root;
	node *q;
public:
	RBtree()
	{
		q = NULL;
		root = NULL;
	}
	void insert(int z); //z를 삽입
	void insertfix(node *); //삽입할 때 규칙 위반되는 경우에 바꿔줄 함수
	void leftrotate(node *); //좌회전
	void rightrotate(node *); //우회전
	void disp(); 
	void display(node *, int space);
};