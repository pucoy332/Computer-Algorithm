/*2017112138 ������*/
#include <iostream>
#include "bstree.cpp"
using namespace std;

class TestData
{
public:
	void setKey(int newKey)
	{
		keyField = newKey;
	}   // Ű ����
	int key() const
	{
		return keyField;
	}     // Ű ��ȯ
private:
	int keyField;   // Ű ��
};

//--------------------------------------------------------------------

void print_help()
{
	cout << endl << "Commands:" << endl;
	cout << "  +key : Insert (or update) data item" << endl;
	cout << "  ?key : Retrieve data item" << endl;
	cout << "  -key : Remove data item" << endl;
	cout << "  Q    : Quit the test program" << endl;
	cout << endl;
}

void main()
{
	BSTree<TestData, int> testTree;   
	TestData testData;              
	int inputKey;                    // ����� �Է� Ű
	char cmd;                        // �Է��� ���ɾ�

	print_help();

	do
	{
		testTree.showStructure();           // ���

		cout << endl << "Command: ";                  
		cin >> cmd;
		if (cmd == '+' || cmd == '?' ||
			cmd == '-' || cmd == '<')
			cin >> inputKey;

		switch (cmd)
		{
		case '+':                       // ������ ������ ����
			testData.setKey(inputKey);
			cout << "Insert : key = " << testData.key()
				<< endl;
			testTree.insert(testData);
			break;

		case '?':                         // ������ ������ �˻� 
			if (testTree.retrieve(inputKey, testData))
			{
				cout << "Retrived : key = " << testData.key() << endl;
			}
			else
				cout << "Not found" << endl;
			break;

		case '-':                         // ������ ������ ����
			if (testTree.remove(inputKey))
				cout << "Removed data item" << endl;
			else
				cout << "Not found" << endl;
			break;

		case 'C': case 'c':               // Ʈ�� ����
			cout << "Clear the tree" << endl;
			testTree.clear();
			break;

		case 'Q': case 'q':              // ����
			break;

		default:                               
			cout << "Inactive or invalid command" << endl;
		}
	} while ((cmd != 'Q') && (cmd != 'q'));

}
