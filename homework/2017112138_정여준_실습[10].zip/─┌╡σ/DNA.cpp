﻿/*2017112138 정여준*/
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <random>
using namespace std;

#define DNA_SIZE 1000000
#define MISMATCH 3//mismatch 허용 개수

int GetRand(int min, int max); //random_device를 사용해서 난수 생성
void makeReferenceDNA(char DNA[]);//Reference D녹NA 시퀀스 생성
char change(char c); //ShortRead 길이당 0~2개의 다른 문자를 만들기 위해 변환하는 함수
void makeMyDNA(char DNA[], int Length); //My DNA 시퀀스를 My_DNA(시퀀스의 길이).txt 파일로 저장된다. 
void makeShortRead(char string[], int Length, int Num);//입력받은 문자열에서 랜덤한 위치의 Short Read를 추출하여 파일에 저장하는 함수
void RestoreDNA(int Length, int Num); //ShortRead와  Reference DNA를 사용해서 My_DNA 복구
void misCount(char DNA_str1[], char DNA_str2[], int Length, int Num);//다른 횟수를 카운트하고 복구율을 출력하는 함수

int GetRand(int min, int max) {
	random_device rn;
	mt19937_64 rnd(rn());
	uniform_int_distribution<int> range(min, max);

	return range(rnd);
}

void makeReferenceDNA(char DNA[]) 
{ 
	ofstream ofs("Reference_DNA.txt");
	for (int i = 0; i < DNA_SIZE; i++) {
		int randNum = GetRand(0, 3);
		ofs << DNA[randNum];
	}
	ofs.close();
}

char change(char c)
{
	int random = GetRand(0, 3);

	if (random == 0)
		c = 'A';
	else if (random == 1)
		c = 'C';
	else if (random == 2)
		c = 'G';
	else
		c = 'T';

	return c;
}

void makeMyDNA(char DNA[], int Length) 
{
	
	ifstream ifs("Reference_DNA.txt");
	ofstream ofs("My_DNA" + to_string(Length) + ".txt");
	char* reference_str = new char[DNA_SIZE + 1]; //Reference_DNA 시퀀스 문자열을 받아올 문자열 생성
	char* MyDNA_str = new char[DNA_SIZE + 1];
	ifs.getline(reference_str, DNA_SIZE + 1);
	strcpy_s(MyDNA_str, DNA_SIZE + 1, reference_str); //받아온 문자열을 복사
	int i = 0;
	while(1){
		if (i > DNA_SIZE - Length)
			break;
		//Reference DNA 시퀀스와 길이당 0~2개의 다른 문자열을 만들기 위해 난수를 생성해 그 수를 인덱스로 하는 문자를 바꿔준다. 
		int a = i + GetRand(0, Length); 
		int b = i + GetRand(0, Length);
		for (int j = i; j < Length+i; j++)
		{
			if (j == a)
				MyDNA_str[j] = change(MyDNA_str[j]);
			if (j == b)
				MyDNA_str[j] = change(MyDNA_str[j]);
		}
		i += Length;
	}
	ofs << MyDNA_str;
	ofs.close();
	ifs.close();
	//데이터 삭제
	delete[] reference_str;
	delete[] MyDNA_str;
}

void makeShortRead(char m_string[], int Length, int Num) {
	ofstream ofs("ShortRead" + to_string(Length) + ".txt");
	for (int j = 0; j < Num; j++) {
		string str = "";
		long long startPoint = GetRand(0, DNA_SIZE - Length);
		for (int i = 0; i < Length; i++) {
			str += m_string[startPoint + i];
		}
		ofs << str;
		ofs << endl;
	}
	ofs.close();
}

void RestoreDNA(int Length, int Num) {
	ifstream ifs1("ShortRead" + to_string(Length) + ".txt");
	ifstream ifs2("Reference_DNA.txt");
	ifstream ifs3("My_DNA" + to_string(Length) + ".txt");
	ofstream ofs("Restore_DNA" + to_string(Length) + ".txt");
	char* shortRead = new char[Length + 1];
	char* DNA_str = new char[DNA_SIZE + 1];
	char* restore_str = new char[DNA_SIZE + 1];
	char* My_DNA = new char[DNA_SIZE + 1];

	ifs2.getline(DNA_str, DNA_SIZE + 1); //Reference DNA 불러옴
	ifs3.getline(My_DNA, DNA_SIZE + 1);	//MY DNA 불러옴
	strcpy_s(restore_str, DNA_SIZE + 1, DNA_str); //복구할 문자열에 Reference DNA 복사
	
	int count = 0;
	for (int i = 0; i < Num; i++)
	{
		ifs1.getline(shortRead, Length + 1); //ShortRead 한줄씩 불러옴
		for (int j = 0; j < Num - Length; j++)
		{
			for (int k = 0; k < Length; k++)
			{
				if (shortRead[k] != DNA_str[j + k]) //비교해서 틀릴때마다 카운트
					count++;
			}
			if (count <= MISMATCH) //mismatch 허용개수보다 적을 경우 
			{
				for (int k = 0; k < Length; k++)
					restore_str[j + k] = shortRead[k];
			}
			count = 0;
		}	
	}
	
	ofs << restore_str;
	misCount(My_DNA, restore_str, Length, Num); //복구한 시퀀스와 My DNA 시퀀스 비교해서 복구율 구하기

	//데이터 삭제
	delete[] shortRead;
	delete[] DNA_str;
	delete[] restore_str;
	delete[] My_DNA;

	ifs1.close();
	ifs2.close();
	ifs3.close();
	ofs.close();
}

void misCount(char DNA_str1[], char DNA_str2[], int Length, int Num) {
	cout << "k =  " << Length << "\t" << "n = " << Num << "\t" << endl;
	int count = 0;
	for (int i = 0; i < DNA_SIZE; i++) {
		if (DNA_str1[i] != DNA_str2[i]) {
			count++;
		}
	}
	if (count == 0) cout << "모두 일치합니다." << endl;
	else {
		cout << count << "개 일치하지 않습니다.\n";
		printf("복구율 : %.2f%%\n", (float(DNA_SIZE) - float(count)) / float(DNA_SIZE) * 100);
	}
}

int main() {
	time_t start, end;
	double result;
	char DNA[4] = { 'A','G','C','T' };
	int k1, k2;
	int n1, n2;
	cout << "길이 k 입력: ";
	cin >> k1;
	cout << "개수 n 입력: ";
	cin >> n1;
	cout << "길이 k 입력: ";
	cin >> k2;
	cout << "개수 n 입력: ";
	cin >> n2;
	
	makeReferenceDNA(DNA);
	
	makeMyDNA(DNA, k1);
	makeMyDNA(DNA, k2);
	
	ifstream ifs1("My_DNA" + to_string(k1) + ".txt");
	ifstream ifs2("My_DNA" + to_string(k2) + ".txt");
	char* DNA_str1 = new char[DNA_SIZE + 1];
	char* DNA_str2 = new char[DNA_SIZE + 1];
	ifs1.getline(DNA_str1, DNA_SIZE + 1);
	ifs2.getline(DNA_str2, DNA_SIZE + 1);

	makeShortRead(DNA_str1, k1, n1);
	makeShortRead(DNA_str2, k2, n2);

	start = clock();
	RestoreDNA(k1, n1);
	end = clock();
	result = (double)(end - start);
	printf("실행 시간 : %.3fms\n\n", result);
	
	start = clock();
	RestoreDNA(k2, n2);
	end = clock();
	result = (double)(end - start);
	printf("실행 시간 : %.3fms\n\n", result);

	delete[] DNA_str1;
	delete[] DNA_str2;
}
